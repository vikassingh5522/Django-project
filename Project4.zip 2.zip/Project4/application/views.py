
from django.shortcuts import render, redirect
from django.http import HttpResponse

from application.models import enquiry_table
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponseRedirect
from django.contrib.auth.decorators import login_required


# Create your views here.

def home(request):
    
    return render(request, 'index.html')

def aboutus(request):
    
    return render(request, 'about.html')

def problem_statement(request):
    
    return render(request, 'projects.html')

def project_scope(request):
    
    return render(request, 'services.html')

def contactus(request):
        
    if request.method=='POST':
        a = request.POST.get('name')
        b = request.POST.get('email')
        c = request.POST.get('phone')
        d = request.POST.get('message')

        info = enquiry_table(name = a, email = b, phone = c, message = d)
        info.save()
        messages.success(request, 'Enquiry has been sent successfully...')  

    return render(request, 'contact.html')

def login_user(request):

    if request.method =='POST':
        a = request.POST['username']
        b = request.POST['password']

        user = authenticate(request, username = a, password = b)

        if user is not None:
           
            login(request, user)
            request.session['username_id'] = a
            return redirect('dashboard')
            
        else:
            
            messages.error(request, 'In-correct username or password!..')    

    return render(request, 'login.html')

@login_required(login_url='login')
def dashboard(request):

    print('You are logged in, Hi', request.session.get('username_id'))
    return render(request, 'dashboard/index.html')

@login_required(login_url='login')
def reg(request):

    info = enquiry_table.objects.all()
    # contact is table name which we create in models.py
    data = {'abc':info}

    return render(request, 'dashboard/tables.html', data)

def delete_record(request, id):
    if request.method=='POST':
        data = enquiry_table.objects.get(pk=id)
        data.delete()
    return HttpResponseRedirect('/reg-details/')

def edit_record(request, id):
    info = enquiry_table.objects.filter(pk=id)
    
    data = {'information':info}
    return render(request, 'dashboard/editrecord.html', data)

def update_record(request, id):
    info = enquiry_table.objects.get(pk=id)
    
    info.name = request.POST.get('name')
    info.email = request.POST.get('email')
    info.phone = request.POST.get('phone')
    info.message = request.POST.get('message')
    info.save()

    return HttpResponseRedirect('/reg-details/')
